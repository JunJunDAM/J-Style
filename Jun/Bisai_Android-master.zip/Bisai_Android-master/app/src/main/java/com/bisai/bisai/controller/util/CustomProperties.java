package com.bisai.bisai.controller.util;

/**
 * Created by sergi on 17/04/2017.
 */

public class CustomProperties {
    public static String clientId = "bisaiapp";
    public static String clientSecret = "my-secret-token-to-change-in-production";
    public static String grantType = "password";
    public static String scope = "read write";
    public static String baseUrl = "http://192.168.22.62:8080";
}
