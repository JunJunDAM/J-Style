package com.bisai.bisai.model;

/**
 * Created by sergi on 05/04/2017.
 */

public enum Permiso {

    INVITAR, MODIFICAR, EXPULSAR

}
